## About
***

### References?

Resources used or referred to during the build of this app:

* __Shiny App:__ Shiny App package. [Link](http://shiny.rstudio.com/)
* __Shiny Themes:__ Shiny Themes package. [Link](http://rstudio.github.io/shinythemes/)
* __DOHMH New York City Restaurant Inspection Results:__ DOHMH New York City Restaurant Inspection Results.  | NYC Open Data [Link](https://data.cityofnewyork.us/Health/DOHMH-New-York-City-Restaurant-Inspection-Results/43nn-pn8j)


<br> 

### About me?

This app was created by Vinayak Kamath. I am a data enthusiast. If you'd like to get in touch; talk about this app, or make a suggestion on using a different or better feature, I can be contacted via [email](emailto:vinayak.kamath92@cunyspsmail.com).

My Github [Handle](https://github.com/kamathvk1982).
